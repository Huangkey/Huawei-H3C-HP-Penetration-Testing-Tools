Metasploit Modules
==================

这些脚本是rb，如果需要使用请添加到Metasploit框架，需要将它们添加到modules/auxiliary/scanner/snmp中

Known issues
============

 * H3C config eater not ready yet
 * H3C config downloader not 100% effective yet, needs more testing

